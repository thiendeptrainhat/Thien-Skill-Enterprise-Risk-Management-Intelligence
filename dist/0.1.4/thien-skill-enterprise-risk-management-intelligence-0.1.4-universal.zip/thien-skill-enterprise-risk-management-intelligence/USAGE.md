# Sử dụng và mức hỗ trợ

## Cài đặt

Mỗi ZIP chứa một thư mục `thien-skill-enterprise-risk-management-intelligence`
ở gốc. Không có lớp `.agents/skills/`. Giữ nguyên cả thư mục để links, scripts,
schema, logo và hồ sơ pháp lý hoạt động cùng nhau.

| Bề mặt | Cách dự kiến / bằng chứng hiện tại |
| --- | --- |
| Claude Web | Add skill rồi tải ZIP folder-root theo tài liệu chính thức; **NOT_RUN** trên tài khoản/bản ZIP này |
| Claude Code | Bản 0.1.3 đã kiểm native explicit/implicit, core và Office có giới hạn; audit phát hiện lỗi trả lời tự do. Candidate 0.1.4 cần evidence hồi quy riêng |
| ChatGPT Web | `Plugins → Skills → Create → Upload`; bản 0.1.3 đã kiểm logo, core, Office và một ca implicit có giới hạn; 0.1.4 chưa upload/native-test tại lúc build. Evidence tại `qa/G9-NATIVE.json` của repository |
| ChatGPT Desktop | Cơ chế native chưa kiểm chứng; không dùng Codex task thay bằng chứng Desktop. **NOT_RUN** |
| Universal | Folder-root để import/copy theo bề mặt hỗ trợ skill; không tuyên bố native install nếu chưa thử |

Không cần plugin wrapper ở dòng phiên bản 0.1.x. Chỉ xem lại khi native evidence yêu
cầu cơ chế khác; không tự cài, upload hoặc publish vì việc có ZIP không cấp quyền.

## Sử dụng

Gọi `$thien-skill-enterprise-risk-management-intelligence`, nêu câu hỏi/đầu ra,
người ra quyết định, organization scope, as-of, horizon, jurisdiction, currency,
unit và nguồn. Với câu hỏi hẹp, không cần tạo engagement đầy đủ. Với snapshot
máy đọc, kiểm tra bằng Python standard library:

```bash
python3 scripts/validate_engagement.py engagement.json
```

Phép tính lõi dùng request JSON gồm `operation`, `parameters`, và `context` có
`unit`, `currency`, `horizon`, `source_refs`; xem danh sách bằng `--help`:

```bash
python3 scripts/erm_core.py --input calculation.json --output result.json
python3 scripts/report.py engagement.json --out new-report-directory
```

Các script từ chối ghi đè output. `report.py` tạo `report.json` và HTML độc lập,
offline. `export_office.mjs` là exporter tùy chọn cho môi trường có đúng runtime
`@oai/artifact-tool` và `docx`; chạy bản copy trong temp directory có
`node_modules` trỏ tới dependency được môi trường cho phép. Không cài package để
ép chạy và không dùng exporter như bằng chứng dữ liệu/phương pháp đúng.

## Ý nghĩa phiên bản 0.1.x

Đây là **Testing**, chưa phải bản hoàn thiện 1.0.0. Static, quantitative,
synthetic behavior và sample artifact đã được kiểm thử theo bằng chứng phát
hành. Native tests mới có phạm vi giới hạn trên Claude Code và ChatGPT Web;
Claude Web/ChatGPT Desktop vẫn NOT_RUN. Source register là điểm tra cứu, không
phải bản sao tiêu chuẩn; phải xác minh nguồn, luật và capability tại thời điểm dùng.

Mọi đầu ra là dự thảo cho đến authority phù hợp phê duyệt. Skill không tự gửi,
upload, cài đặt, thay production threshold, accept breach hoặc sửa skill khác.

## Thay đổi contract 0.1.3

Handoff validated cần validation status đạt và source evidence IDs current.
Treatment hỗ trợ no_action_case/target/target_assessment_ids; xem reference reporting.
Office chuẩn hóa chỉ các ô định lượng; giới hạn 15 chữ số có nghĩa và decimal
round-trip. Số vượt độ chính xác bị từ chối rõ, giữ giá trị gốc trong JSON; cần
người dùng xác định rescale/rounding phù hợp trước xuất Excel. Không đổi ID thành số.
Dùng `export_office.mjs report.json output-dir logo.png preview-dir --check`
để kiểm công thức/counts mà không render hay sinh file Office. Kiểm này không
thay visual QA. 
## Bản thử 0.1.4

Bổ sung profit_bridge có factors và đối soát vào pass_through; yêu cầu kiểm cả
số trong lời giải, không chỉ tổng cuối. Làm rõ materiality chưa biết, reverse
stress và tỷ lệ hàm ý từ scenario. Word dùng Normal rõ ràng, body 6pt after,
H1 16/8pt và H2 12/6pt before/after; bỏ paragraph override làm lệch heading.
Đây là Testing; phạm vi hồi quy thực chạy được ghi theo candidate trong QA,
không kế thừa PASS native của bản cũ cho nội dung đã sửa.
